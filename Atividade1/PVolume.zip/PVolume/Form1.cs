﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class frmVolume : Form
    {

        Double raio;
        Double altura;
        Double volume;

        // double por conta da possibilidade de ser um número quebrado

        public frmVolume()
        {
            InitializeComponent();
        }

       

        
        private void txtRaio_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtRaio.Text, out raio))
            //! funciona como negação, seguido pelo tipo de dado - ou seja, se não for tipo de dado X, é inválido
            // quero testar se o valor na variável é válido, e se for, quero que saia na variável raio
            // ! equivale a == false
            {
                MessageBox.Show("Valor de raio inválido!");
                txtRaio.Text = "";
                txtRaio.Focus();
                // até aqui, já seria o suficiente se eu quisesse vetar apenas valores não numéricos, mas 0 e -(X) também seriam inválidos nesse válculo, então é necessário fazer testes que tb os vetem
            }
            else
                if (raio <= 0)
            {
                MessageBox.Show("Raio deve ser maior que zero!");
                txtRaio.Text = "";
                txtRaio.Focus();
                // para ficar mais amigável ao usuário, fazem-se dois diferentes testes, para que o apontamento do erro seja mais preciso - em ujm dos casos, o dado não era numérico, em outro, o número dadp estava fora da ampliotude permitida
            }
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Valor de altura inválido!");
                txtAltura.Text = "";
                txtAltura.Focus();
            }
            else
                if (altura <= 0)
            {
                MessageBox.Show("Altura deve ser maior que zero!");
                txtAltura.Text = "";
                txtAltura.Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            // volume = 3.14 * raio * raio * altura;
            volume = (Math.PI * Math.Pow(raio, 2) * altura);
            txtVolume.Text = volume.ToString("N2");
            // tem que converter o dado double para texto, pois a caixa de saída é texto
         }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtRaio.Clear();
            txtVolume.Clear();

            txtRaio.Focus();
        }
    }
}
