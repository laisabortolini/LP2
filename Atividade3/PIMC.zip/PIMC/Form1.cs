﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMC
{
    public partial class Form1 : Form
    {
        double altura;
        double peso;
        double imc;
        public Form1()
        {
            InitializeComponent();
        }
        private void txtAltura_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            double altura = Double.Parse(txtAltura.Text);
        }
        private void txtPeso_TextChanged(object sender, EventArgs e)
        {
            double peso = Double.Parse(txtPeso.Text);
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtAltura.Text, out altura))
            {
                txtAltura.Text = "";
                txtAltura.Focus();
            }
            if (!Double.TryParse(txtPeso.Text, out peso))
            {
                txtPeso.Text = "";
                txtPeso.Focus();
            }

            imc = peso / (altura * altura);
            txtImc.Text = imc.ToString("N2");

            imc = Math.Round(imc, 1);


            if (imc < 18)
            {
                MessageBox.Show("Magreza - Obesidade Nível 0");
            }
            else if (imc >= 18 && imc < 25)
            {
                MessageBox.Show("Normalidade - Obesidade Nível 0");
            }
            else if (imc >= 25 && imc < 29)
            {
                MessageBox.Show("Sobrepeso - Obesidade Nível 1");
            }
            else if (imc >= 30 && imc < 40)
            {
                MessageBox.Show("Obesidade - Obesidade Nível 2");
            }
            else if (imc > 40)
            {
                MessageBox.Show("Obesidade - Obesidade Nível 3");
            }                
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtPeso.Clear();

            txtAltura.Focus();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnHELPPROF_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Prof, tentei o que você sugeriu. Nada funciona e o prazo bateu, desculpa (ृʾ́꒳ʿ̀ ृ　)ु");
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(txtAltura.Text);
            MessageBox.Show(txtPeso.Text);
        }

        private void txtImc_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
