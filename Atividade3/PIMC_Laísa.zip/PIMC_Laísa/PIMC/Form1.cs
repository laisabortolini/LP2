﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMC
{
    public partial class Form1 : Form
    {
        double altura, peso, imc;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Clear();
            mskbxPeso.Clear();
        }
        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxAltura.Text, out altura))
                MessageBox.Show("Altura Inválida! ònó");
        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxPeso.Text, out peso))
                MessageBox.Show("Peso Inválido! ònó");
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxAltura.Text, out altura))
            {
                MessageBox.Show("Altura Inválida! ònó");
                mskbxAltura.Focus();
            }
            else
                if (!double.TryParse(mskbxPeso.Text, out peso))
                {
                    MessageBox.Show("Peso Inválido! ònó");
                    mskbxPeso.Focus();
                }
                else
                {
                    imc = peso / Math.Pow(altura, 2);
                    imc = Math.Round(imc, 1);

                    if (imc < 18.5)
                        MessageBox.Show(("Seu IMC: ") + imc + (", é classificado como Magreza"));
                    else if (imc <= 24.9)
                        MessageBox.Show(("Seu IMC: ") + imc + (", é classificado como Normal"));
                    else if (imc <= 29.9)
                        MessageBox.Show(("Seu IMC: ") + imc + (", é classificado como Sobrepeso"));
                    else if (imc <= 39.9)
                        MessageBox.Show(("Seu IMC: ") + imc + (", é classificado como Obesidade"));
                    else
                        MessageBox.Show(("Seu IMC: ") + imc + (", é classificado como Obesidade Grave"));
                }
           
        }
    }
}
