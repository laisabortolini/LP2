﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class frmTriangulo : Form
    {
        double ladoA, ladoB, ladoC;

        public frmTriangulo()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
        }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoA.Text, out ladoA))
                MessageBox.Show("Valor inválido, insira novamente! õnó");
        }

        private void txtLadoB_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoB.Text, out ladoB))
                MessageBox.Show("Valor inválido, insira novamente! õnó");
        }

        private void txtLadoC_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoC.Text, out ladoC))
                MessageBox.Show("Valor inválido, insira novamente! õnó");
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoA.Text, out ladoA))
            {
                MessageBox.Show("Inválido! ònó");
            }
            else
                if (!double.TryParse(txtLadoB.Text, out ladoB))
                {
                    MessageBox.Show("Inválido! ònó");
                }
            else
                    if (!double.TryParse(txtLadoC.Text, out ladoC))
                    {
                        MessageBox.Show("Inválido! ònó");

                    } 
            else
                    {
                        if ((ladoA < (ladoB + ladoC)) &&
                         (ladoA > Math.Abs(ladoB - ladoC)) &&
                         (ladoB < (ladoA + ladoC)) &&
                         (ladoB > Math.Abs(ladoA - ladoC)) &&
                         (ladoC < (ladoA + ladoB)) &&
                         (ladoC > Math.Abs(ladoA - ladoB)))
                        {

                            if ((ladoA == ladoB) && (ladoB == ladoC))
                            {
                                MessageBox.Show("Triângulo Equilátero");
                            }
                            else if ((ladoA == ladoB) ||
                                    (ladoA == ladoC) ||
                                    (ladoB == ladoC))
                            {
                                MessageBox.Show("Triângulo Isósceles");
                            }
                            else
                            {
                                MessageBox.Show("Triângulo Escaleno");
                            }
                        }
                                    else 
            MessageBox.Show ("Não forma um triângulo");
                    } 
        }
    }
}
