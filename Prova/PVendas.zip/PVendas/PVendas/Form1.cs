﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVendas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int qtdemeses = 8, semanasmes = 4; // meu RA acaba em 8, totalizando 8 meses i max = 8
            double totalgeral = 0;
            double totalmes = 0;
            double[,] vendas = new double[qtdemeses, semanasmes];
            string valor;

            for (int i = 0; i < qtdemeses; i++) // i eh qtde meses - linha
            {
                for (int j = 0; j < semanasmes; j++) // j eh qtde semanas - coluna
                {

                        valor = Interaction.InputBox("Mês: " + (i + 1) + ", Semana: " + (j + 1));
                        if (double.TryParse(valor, out vendas[i, j])) // validando valor numerico de entrada
                        {
                            totalgeral += vendas[i, j];
                        }
                        else
                            MessageBox.Show("Entrada Não Aceita!");

                }
            }
            lstbxValMeses.BeginUpdate(); // imprimir os valores das vendas na list box
            for (int i = 0; i < qtdemeses; i++)
            {
                totalmes = 0;
                for (int j = 0; j < semanasmes; j++)
                {
                    lstbxValMeses.Items.Add("Total do mês: " + (i + 1) + " Semana:" + (j + 1) + " R$" + vendas[i, j].ToString("N2"));
                    totalmes += vendas[i, j];
                }
                lstbxValMeses.Items.Add(">> Total Mês: R$" + totalmes.ToString("N2"));
                lstbxValMeses.Items.Add("---------------------------");
            }
            lstbxValMeses.Items.Add(">> Total Geral: R$" + totalgeral.ToString("N2"));
            lstbxValMeses.EndUpdate();
        }
    }
}
