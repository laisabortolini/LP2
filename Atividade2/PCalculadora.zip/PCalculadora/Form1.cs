﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalculadora
{
    public partial class Form1 : Form
    {

        double num1;
        double num2;
        double resultado;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtResultado.Clear();

            txtNum1.Focus();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("(ﾐゝᆽσﾐ) Good job, buddy, you did the thing on time, meow meow or whatever (ﾐゝᆽσﾐ)");
        }
      
        private void txtNum1_TextChanged(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum1.Text, out num1))
            {
                txtNum1.Text = "";
                txtNum1.Focus();
            }
        }
               
        private void txtNum2_TextChanged(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum2.Text, out num2))
            {
                    txtNum1.Text = "";
                    txtNum1.Focus();   
            }
        }

        private void txtResultado_TextChanged(object sender, EventArgs e)
        {
 
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            resultado = num1 + num2;
            txtResultado.Text = resultado.ToString("N2");
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            resultado = num1 * num2;
            txtResultado.Text = resultado.ToString("N2");
        }

        private void txtNum2_Validated(object sender, EventArgs e)
        {

        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            resultado = num1 - num2;
            txtResultado.Text = resultado.ToString("N2");
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            resultado = num1 / num2;
            txtResultado.Text = resultado.ToString("N2");
        }


    }
}
